#!/bin/bash
source ../env.sh
#export HIVE_CONF_DIR=/data/azkaban-hadoop/command-home/hive-offline/conf

#ScheduleTime="2019-05-06 20:00:00"
if [ $# -eq 1 ]
then
    CUR_DATE=$1
else
    if [ "x" == "${ScheduleTime}x" ]
    then
        CUR_DATE=`date -d '-1 hours' +%Y%m%d%H`
    else
        CUR_DATE=$(date -d "1 hours ago $ScheduleTime" +"%Y%m%d%H")
    fi
fi

time_ymdh=${CUR_DATE}
time_ymd=${CUR_DATE:0:8}
time_yyyy=${CUR_DATE:0:4}
time_mm=${CUR_DATE:4:2}
time_dd=${CUR_DATE:6:2}
time_hh=${CUR_DATE:8:2}

#m_ranker_path_base="s3://mob-emr-test/dataplatform/DataWareHouse/data/dwh/m_ranker_feature_log"
#m_ranker_path="${m_ranker_path_base}/${time_ymd}/${time_hh}"
#m_ranker_path_sucessfile="${m_ranker_path}/_SUCCESS"
#check_sucessfile ${m_ranker_path_sucessfile}



req_table="dwh.m_ranker_feature_log"
req_partition="day=${time_ymd}/hour=${time_hh}"
check_hive_partition ${req_table} ${req_partition}

delete_expired_data_date=`date -d "90 days ago $ScheduleTime" +%Y%m%d`
outputPath_base="s3a://mob-emr-test/dataplatform/DataWareHouse/offline/generate_train_data/m_ranker_bucket"
outputPath="${outputPath_base}/${CUR_DATE}"
delete_expired_path="${outputPath_base}/${delete_expired_data_date}"
hadoop dfs -rmr $outputPath
hadoop dfs -rmr delete_expired_path

#outputPath_base="s3a://mob-emr-test/dataplatform/DataWareHouse/offline/generate_train_data/m_ranker_bucket"

## ===================================================================================
cmd="
spark-submit \
  --class com.mobvista.train_data_flow.task.m_dataflow.MRankerBucket \
  --jars ${EXTRA_JARS} \
  --master yarn \
  --deploy-mode cluster \
  --executor-cores 4 \
  --num-executors 20 \
  --executor-memory 5g \
  --driver-memory 5g \
  --conf spark.sql.shuffle.partitions=2000 \
  --conf spark.default.parallelism=2000 \
  --files ${HIVE_SITE_PATH} \
  --conf spark.yarn.executor.memoryOverhead=4g \
  --conf spark.yarn.maxAppAttempts=0
  ../${JAR} \
  ${CUR_DATE} ${outputPath_base}"
$cmd

if [ $? -ne 0 ]; then
    echo "[validate failed!]"
    exit 255
fi



