#!/usr/bin/env bash

#begin="20190117 13"
#end="20190118 00"
#taskname="FormatLog.sh"

first=$1
second=$2
task=$3

while [ "$first" != "$second" ]
do
echo $first
sh $task ${first:0:8}${first:9:2}
first_ts=`date -d "$first" +%s`
first_ago=$((first_ts+3600))
first=`date -d  @$first_ago +"%Y%m%d %H"`

done