#!/bin/bash
source ../env.sh
#export HIVE_CONF_DIR=/data/azkaban-hadoop/command-home/hive-offline/conf

#ScheduleTime="2019-04-15 17:00:00"
if [ $# -eq 1 ]
then
    CUR_DATE=$1
else
    if [ "x" == "${ScheduleTime}x" ]
    then
        schedule=`date -d +%Y%m%d`
        CUR_DATE=`date -d '-1 days' +%Y%m%d`

    else
        schedule=`date -d "$ScheduleTime" +%Y%m%d`
        CUR_DATE=$(date -d "1 days ago $ScheduleTime" +"%Y%m%d")
    fi
fi

delete_expired_data_date=`date -d "90 days ago $ScheduleTime" +%Y%m%d`

uhdiiPath="s3a://mob-emr-test/xujian/m_model_online/m_req_dev_user_his_dmp_tag_install_pkg_v2/$CUR_DATE"
uhdiiPath_sucessfile="${uhdiiPath}/_SUCCESS"
check_sucessfile ${uhdiiPath_sucessfile}

outputPath_base="s3a://mob-emr-test/dataplatform/DataWareHouse/offline/generate_train_data/m_uhdii_bucket"
outputPath="${outputPath_base}/day=$CUR_DATE"
delete_expired_path="${outputPath_base}/day=${delete_expired_data_date}"
hadoop fs -rmr ${outputPath}
hadoop fs -rmr ${delete_expired_path}

## ===================================================================================
cmd="
spark-submit \
  --class com.mobvista.train_data_flow.task.m_dataflow.UhdiiBucket \
  --jars ${EXTRA_JARS} \
  --master yarn \
  --deploy-mode cluster \
  --executor-cores 4 \
  --num-executors 50 \
  --executor-memory 10g \
  --driver-memory 10g \
  --conf spark.sql.shuffle.partitions=2000 \
  --files ${HIVE_SITE_PATH} \
  --conf spark.yarn.executor.memoryOverhead=4g \
  --conf spark.yarn.maxAppAttempts=0
  ../${JAR} \
  $CUR_DATE $uhdiiPath $outputPath_base"
$cmd

if [ $? -ne 0 ]; then
    echo "[validate failed!]"
    exit 255
fi



