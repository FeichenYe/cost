#!/bin/bash
source ../env.sh
#export HIVE_CONF_DIR=/data/azkaban-hadoop/command-home/hive-offline/conf


#6小时之前日志
#ScheduleTime="2019-09-18 09:00:00"
if [ $# -eq 1 ]
then
    CUR_DATE=$1
else
    if [ "x" == "${ScheduleTime}x" ]
    then
        CUR_DATE=`date -d '-1 hours' +%Y%m%d%H`
        YESTERDAY_YMD=`date -d '-1 days' +%Y%m%d`
        KUDU_EXPIRE_DATE=`date -d '-2160 hours' +%Y%m%d%H`
    else
        CUR_DATE=$(date -d "1 hours ago $ScheduleTime" +"%Y%m%d%H")
        YESTERDAY_YMD=$(date -d "1 days ago $ScheduleTime" +"%Y%m%d")
        KUDU_EXPIRE_DATE=$(date -d "2160 hours ago $ScheduleTime" +"%Y%m%d%H")
    fi
fi


time_ymdh=${CUR_DATE}
time_ymd=${CUR_DATE:0:8}
time_yyyy=${CUR_DATE:0:4}
time_mm=${CUR_DATE:4:2}
time_dd=${CUR_DATE:6:2}
time_hh=${CUR_DATE:8:2}

time_now=$CUR_DATE


tracking_install_path="s3a://mob-emr-test/dataplatform/DataWareHouse/offline/generate_train_data/install/$time_ymd/$time_ymdh/_SUCCESS"
check_sucessfile ${tracking_install_path}
############################################################
## check tracking_log

#track_path="s3://mob-ad/adn/tracking-v3/"
#logtype=("impression_cpc" "impression" "click_cpc" "click" "install" "only_impression")
#for i in ${logtype[@]}
#do
#    input_path=${track_path}${i}/${time_now:0:4}/${time_now:4:2}/${time_now:6:2}/*/${time_now:8:2}/
#    check_sucessfile ${input_path}
#done

#function check_ready(){
#        table=$1
#for i in `seq 1 5`
#do
#        hive -e "
#        use dev;
#        select dayhour from $table where dayhour ='$time_now' limit 1
#        " >11
#        last_hour_info=`cat 11 | tail -1`
#        if [ "$last_hour_info" == "$DATE" ]; then
#                return 0
#            #echo "$last_hour is not ready!"
#
#        fi
#        sleep 5m
#done
#echo "$last_hour is not ready!"
#return 1
#}
#
#check_ready generate_train_data.install || exit 1

############################################################
## check 词表 (ftrl这个目录后面多个06，注意一下)
get_ftrl_lastest_date() {
    local path="$1"
    local datehour="$2"

    while [[ true ]];
    do
        local date=${datehour:0:8}
        local hour=${datehour:8:2}
        # 这个目录后面多个06
        local check_path="$path/$date/${datehour}06/_SUCCESS"
        if hadoop fs -ls $check_path > /dev/null 2>&1
        then
            echo $datehour
            break
        fi
            local datehour=$(date -d "$date $hour 1 hour ago" "+%Y%m%d%H")
    done
}

ftrl_base_path="s3://mob-emr-test/wanjun/m_sys_model/offline_feature_zsl"
vcr_base_path="s3://mob-emr-test/wanjun/m_sys_model/feature_config"
mooc_base_path="s3://mob-emr-test/wanjun/m_sys_model/ctcvr_offer_creative/extra5_creative_data_hourly"

if [ ${#time_now} -eq 8 ];then
    ftrl_path="${ftrl_base_path}/$time_now/${time_now}2306/m_ftrl_offline_feature.dat"
    vta_path="${vcr_base_path}/$time_now/${time_now}21/vta_campaign.txt"
    cpe_path="${vcr_base_path}/$time_now/${time_now}21/cpe_campaign.txt"
    rank_path="${vcr_base_path}/$time_now/${time_now}21/package_board_rank.dat"
    mooc_feature_path="$mooc_base_path/${time_now}/*/*"
else
    #check 最近的ftrl配置文件目录
    ftrl_lastest_datehour=$(get_ftrl_lastest_date "$ftrl_base_path" "$time_now")
    ftrl_path="${ftrl_base_path}/${ftrl_lastest_datehour:0:8}/${ftrl_lastest_datehour}06/m_ftrl_offline_feature.dat"
    #ftrl_path="s3://mob-emr-test/wanjun/m_sys_model/offline_feature_zsl/m_ftrl_offline_feature.dat"

    #check 最近的vta,cpe,rank配置文件目录
    vcr_lastest_datehour=$(get_lastest_date "$vcr_base_path" "$time_now")
    vta_path="${vcr_base_path}/${vcr_lastest_datehour:0:8}/${vcr_lastest_datehour}/vta_campaign.txt"
    cpe_path="${vcr_base_path}/${vcr_lastest_datehour:0:8}/${vcr_lastest_datehour}/cpe_campaign.txt"
    rank_path="${vcr_base_path}/${vcr_lastest_datehour:0:8}/${vcr_lastest_datehour}/package_board_rank.dat"

    #check mooc_creative
    mooc_feature_path="$mooc_base_path/${time_now:0:8}/$time_now"
    mooc_path_sucessfile="${mooc_feature_path}/_SUCCESS"
    send_mail_wait_time=180
    send_mail_to_owner_mooc="jun.wan@mobvista.com,nanjun.jiang@mobvista.com"
    check_sucessfile_send_mail ${mooc_path_sucessfile} ${send_mail_wait_time} ${send_mail_to_owner_mooc}

fi




############################################################
## check uhdii

#m_uhdii_bucket_table="dev.m_uhdii_bucket"
#m_uhdii_bucket_partition="day=${YESTERDAY_YMD}"
#is_exit_ins=`check_hive_partition_isExist ${m_uhdii_bucket_table} ${m_uhdii_bucket_partition}`

#is_exit_ins=""
#install_pathList="none"

############################################################
## check crt_md5_path and third_party_path
get_file_lastest_date() {
    local path="$1"
    local datehour="$2"
    local file="$3"

    while [[ true ]];
    do
        local date=${datehour:0:8}
        local hour=${datehour:8:2}
        local check_path="$path/$date/${datehour}/${file}"
        if hadoop fs -ls $check_path > /dev/null 2>&1
        then
            echo $datehour
            break
        fi
        local datehour=$(date -d "$date $hour 1 hour ago" "+%Y%m%d%H")
    done
}
crt_md5_base="s3://mob-emr-test/wanjun/m_sys_model/creative_optimize/offline_data/history_data"
crt_md5_name="creative_md5.dat"
crt_md5_latest_datehour=$(get_file_lastest_date "$crt_md5_base" "$time_now" "$crt_md5_name")
crt_md5_path="${crt_md5_base}/${crt_md5_latest_datehour:0:8}/${crt_md5_latest_datehour}/${crt_md5_name}"

third_party_base="s3://mob-emr-test/wanjun/m_sys_model/offline_data/history_data"
third_party_name="campaign_third_party.dat"
third_party_lastest_datehour=$(get_file_lastest_date "$third_party_base" "$time_now" "$third_party_name")
third_party_path="${third_party_base}/${third_party_lastest_datehour:0:8}/${third_party_lastest_datehour}/${third_party_name}"

############################################################
## check Realtime

#m_ranker_bucket_table="dwh.m_ranker_feature_log"
#m_ranker_bucket_partition="day=${time_ymd}/hour=${time_hh}"
##m_ranker_bucket_table="dev.m_ranker_bucket"
##m_ranker_bucket_partition="day=${time_ymd}/dayhour=${time_ymdh}"
#check_hive_partition ${m_ranker_bucket_table} ${m_ranker_bucket_partition}





##删除输出目录 & 删除3个月前的备份数据
#outputPath_base="s3a://mob-emr-test/dataplatform/DataWareHouse/offline/generate_train_data/m_dataflow"
outputPath_base="s3a://mob-emr-test/dataplatform/DataWareHouse/offline/generate_train_data/test/m_dataflow_new"


#outputPath_base="s3a://mob-emr-test/dataplatform/DataWareHouse/offline/generate_train_data/m_dataflow_creative3_v1"
outputPath="${outputPath_base}/${time_ymd}/${CUR_DATE}"
#rm_data=`date -d '90 day ago' +%Y%m%d`
#rm_path=${outputPath_base}/${rm_data}
hadoop dfs -rmr ${outputPath}
#hadoop dfs -rmr ${rm_path}


#ftrl_path="s3://mob-emr-test/wanjun/m_sys_model/offline_feature_zsl/20190918/201909180806/m_ftrl_offline_feature.dat"
#vta_path="s3://mob-emr-test/wanjun/m_sys_model/feature_config/20190918/2019091806/vta_campaign.txt"
#cpe_path="s3://mob-emr-test/wanjun/m_sys_model/feature_config/20190918/2019091806/cpe_campaign.txt"
#rank_path="s3://mob-emr-test/wanjun/m_sys_model/feature_config/20190918/2019091806/package_board_rank.dat"
#mooc_feature_path="s3://mob-emr-test/wanjun/m_sys_model/ctcvr_offer_creative/extra5_creative_data_hourly/20190918/2019091808"
#crt_md5_path="s3://mob-emr-test/wanjun/m_sys_model/creative_optimize/offline_data/history_data/20190918/2019091808/creative_md5.dat"
#third_party_path="s3://mob-emr-test/wanjun/m_sys_model/offline_data/history_data/20190918/2019091808/campaign_third_party.dat"

is_exit_ins="1"
install_pathList="1"

############################################################
## start spark
spark-submit \
  --class com.mobvista.train_data_flow.task.m_dataflow.DataflowMSystem \
  --jars ${EXTRA_JARS} \
  --master yarn \
  --deploy-mode cluster \
  --files ${HIVE_SITE_PATH} \
  --executor-cores 1 \
  --num-executors 100 \
  --executor-memory 3g \
  --driver-memory 4g \
  --conf "spark.driver.extraJavaOptions=-XX:+UseG1GC" \
  --conf "spark.executor.extraJavaOptions=-XX:+UseG1GC" \
  ../${JAR} \
  -date $CUR_DATE \
  -ftrl_path $ftrl_path \
  -vta_path $vta_path \
  -cpe_path $cpe_path \
  -rank_path $rank_path \
  -mooc_path $mooc_feature_path \
  -is_exit_ins $is_exit_ins \
  -install_pathList $install_pathList \
  -crt_md5_path $crt_md5_path \
  -third_party_path $third_party_path \
  -output_path $outputPath \
  -kudu_expire_date $KUDU_EXPIRE_DATE

if [ $? -ne 0 ]; then
    echo "[validate failed!]"
    exit 255
fi



