#!/bin/bash
source ../env.sh
#export HIVE_CONF_DIR=/data/azkaban-hadoop/command-home/hive-offline/conf
ScheduleTime="2019-11-19 12:10:00"
if [ $# -eq 1 ]
then
    CUR_DATE=$1
    YESTERDAY_YMD=`date -d '-1 days' +%Y%m%d`
else
    if [ "x" == "${ScheduleTime}x" ]
    then
        CUR_DATE=`date -d '-1 hours' +%Y%m%d%H`
        YESTERDAY_YMD=`date -d '-1 days' +%Y%m%d`
    else
        CUR_DATE=$(date -d "1 hours ago $ScheduleTime" +"%Y%m%d%H")
        YESTERDAY_YMD=$(date -d "1 days ago $ScheduleTime" +"%Y%m%d")
    fi
fi

time_now=$CUR_DATE


#################################################################
# lock path
CassandraLockPath="oss://mob-emr-test/dataplatform/DataWareHouse/offline/m_data_flow/cassandra_lock"

#获取传/删oss的jar包
hadoop fs -get oss://mob-emr-test/dataplatform/DataWareHouse/offline/myjar/file-to-oss.jar

# 等待锁
check_sucessfile "${CassandraLockPath}/_lockA"
hadoop fs -rm ${CassandraLockPath}/_lockA

check_sucessfile "${CassandraLockPath}/_lockB"
hadoop fs -rm ${CassandraLockPath}/_lockB
hadoop fs -rm ${CassandraLockPath}/_lockA
#################################################################


#time_now="2019111800"

# 获取最新的dmpDate
#track_path="s3://mob-ad/adn/tracking-v3/"
track_path="oss://mob-emr-test/mob-ad/adn/tracking-v3/"
logtypeList=("impression_cpc" "impression" "click_cpc" "click" "install" "only_impression")
regionList=("frankfurt" "seoul" "singapore" "virginia")
for logtype in ${logtypeList[@]} ; do
    for region in ${regionList[@]} ; do
    input_path=${track_path}${logtype}/${time_now:0:4}/${time_now:4:2}/${time_now:6:2}/${region}/${time_now:8:2}/_SUCCESS
    check_sucessfile ${input_path}
    done
done


# 获取最近生成的SUCCESS目录的日期
get_dmp_lastest_date() {
    local path="$1"
    local datehour="$2"
    local date=${datehour:0:8}

    while [[ true ]];
    do
#        local hour=${datehour:8:2}
        local check_path="$path/$date/_SUCCESS"
        if hadoop fs -ls $check_path > /dev/null 2>&1
        then
            echo $date
            break
        fi
            local date=$(date -d "$date 1 day ago" "+%Y%m%d")
    done
}


# 获取dmp最新cassandra的日期
#dmp_base_path="oss://mob-emr-test/dataplatform/DataWareHouse/offline/m_data_flow/dmpTag"
#dmp_lastest_date=$(get_dmp_lastest_date "$dmp_base_path" "$time_now")

dmp_lastest_date=$(date -d "$date 2 day ago" "+%Y%m%d")


# 删除当前文件
ouput_path="oss://mob-emr-test/dataplatform/DataWareHouse/offline/generate_train_data_oss/get_cassandra_feature/${time_now:0:8}/$time_now"
hadoop dfs -rm -r ${ouput_path}


## ===================================================================================
cmd=
spark-submit \
  --jars ${EXTRA_JARS} \
  --master yarn \
  --deploy-mode cluster \
  --files ${HIVE_SITE_PATH} \
  --class com.mobvista.train_data_flow.task.tracking_get_casssandra_feature.TrackingGetCassandraDmpAndRequest \
  --executor-memory 3G --executor-cores 1 --num-executors 20 --driver-cores 5 \
  ../${JAR} \
  $time_now $dmp_lastest_date

if [[ $? -ne 0 ]]; then
    #任务失败，也要释放锁
    echo "_lockA" > _lockA
    echo "_lockB" > _lockB
    java -jar file-to-oss.jar ${CassandraLockPath} ./_lockB
    java -jar file-to-oss.jar ${CassandraLockPath} ./_lockA
    exit 1
fi

#等待cassandra读完，释放锁
echo "_lockA" > _lockA
echo "_lockB" > _lockB
java -jar file-to-oss.jar ${CassandraLockPath} ./_lockB
java -jar file-to-oss.jar ${CassandraLockPath} ./_lockA
