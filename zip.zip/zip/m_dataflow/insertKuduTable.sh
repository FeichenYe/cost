#!/bin/sh

source ../env.sh

# azkaban: https://dataplatform.mobvista.com:8443/manager?project=scientist-test

if [ $# -eq 1 ]
then
    CUR_DATE=$1
else
    if [ "x" == "${ScheduleTime}x" ]
    then
        CUR_DATE=`date -d '-1 hours' +%Y%m%d%H`
    else
        CUR_DATE=$(date -d "1 hours ago $ScheduleTime" +"%Y%m%d%H")
    fi
fi


#today=${ScheduleTime:-$1}
#today="2019-07-22 19:10:20"

day=${CUR_DATE:0:8}
dayhour=$CUR_DATE
KUDU_EXPIRE_DATE=`date -d '-2160 hours' +%Y%m%d%H`


hive_site_path="/data/azkaban-hadoop/command-home/spark-offline/conf/hive-site.xml"

# 检查_SUCCESS文件,若不存在则复制algo数据
# $1 check path
check_await() {
    while [[ true ]];
    do
        if hadoop fs -ls "$1" > /dev/null 2>&1
        then
            break
        fi
        sleep 300
    done
}

# $1 sql
hive_cmd() {
export HIVE_CONF_DIR=/data/azkaban-hadoop/command-home/hive-offline/conf
# local HIVE_CMD="/data/hadoop-alternative/hive-offline/bin/hive"
# if [ ! -f $HIVE_CMD ];then
  HIVE_CMD="hive"
# fi
${HIVE_CMD} -e "
set hive.cli.print.header=false;
set hive.optimize.index.filter=true;
set mapreduce.task.io.sort.mb=512;
set mapreduce.map.speculative=true;
set mapreduce.reduce.speculative=true;
$1;
"
}

# 挂载hive分区
# $1 table name
# $2 partition
# $3 hdfs path
mount_partition() {
local count=1
local limit=3
while [ $count -le $limit ];do
   hive_cmd "
    use kehan_test;
    ALTER TABLE $1 DROP IF EXISTS PARTITION ($2);
    ALTER TABLE $1 ADD IF NOT EXISTS PARTITION ($2)
        LOCATION '$3';
    "

    if [ $? -eq 0 ];then
      break
    else
      if [ $count -eq $limit ];then
        exit 255
      else
        count=$(( $count + 1 ))
      fi
    fi
done
}




#dateTime="${day}"
#hourTime="${hour}"

#tag_path="s3://mob-emr-test/dataplatform/DataWareHouse/offline/algo_hourly_tag/${hourTime}"
data_org_path="s3://mob-emr-test/dataplatform/DataWareHouse/offline/generate_train_data/test/m_dataflow_new/${day}/${dayhour}"
tag_path="s3://mob-emr-test/dataplatform/DataWareHouse/offline/kudu_tag/base_hourly_tag/${day}/${dayhour}"

check_await "${data_org_path}/_SUCCESS"
echo "数据准备完成"


#挂载分区
mount_partition "algo_data_daily_new" "dt='${dayhour}'" "${data_org_path}"

#kuduTable="m_system_train_data"

echo "begin to insert kudu table"
hadoop fs -rmr ${tag_path}

spark-submit --class com.mobvista.train_data_flow.task.m_dataflow.InsertKuduTable \
	--conf spark.sql.shuffle.partitions=160 \
	--conf spark.default.parallelism=160 \
	--conf spark.yarn.executor.memoryOverhead=1024 \
	--name "m_flow_write_kudu_hourly" \
	--files ${hive_site_path} \
	--master yarn \
	--queue "dataplatform" \
	--deploy-mode cluster \
	--executor-memory 2G \
	--driver-memory 1G \
	--executor-cores 2 \
	--num-executors 50 \
	--jars ${EXTRA_JARS} \
	../train_data_flow.jar $dayhour $KUDU_EXPIRE_DATE || exit 1
	
if [[ $? -ne 0 ]];then
    exit 1
fi

# make success tag
hadoop fs -mkdir -p ${tag_path}
hadoop fs -touchz ${tag_path}/_SUCCESS


