#!/bin/bash
source ../env.sh
## ===================================================================================
cmd="
spark-submit \
  --class com.mobvista.train_data_flow.task.m_dataflow.KuduDemo \
  --jars ${EXTRA_JARS} \
  --master local \
  --executor-cores 1 \
  --num-executors 1 \
  --executor-memory 4g \
  --driver-memory 4g \
  --files ${HIVE_SITE_PATH} \
  ../${JAR} "
$cmd