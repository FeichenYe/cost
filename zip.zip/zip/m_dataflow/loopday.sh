#!/usr/bin/env bash
#!/bin/bash

first=$1
second=$2
task=$3

#begin="20190301"
#end="20190302"
#taskname="m_dataflow.sh"

while [ "$first" != "$second" ]
do
echo $first
sh -x $task ${first}
first_ts=`date -d "$first" +%s`
first_ago=$((first_ts+86400))
first=`date -d  @$first_ago +"%Y%m%d"`
done
