#!/bin/sh

source ./common.sh

inputPath=science_path
out=science_result
cal_path=cal_path

#if [ -f "${out}" ]; then
#rm ${out}
#fi

rm ${cal_path}*
rm ${out}


# 路径去重
sort -u ${inputPath} > distinct_path

# 路径分片
count=0
num=0
for line in `cat distinct_path`
do
num=$[ $count / 30 ]
echo $line >> $cal_path$num
count=$[ $count + 1 ]
done

# 清理标记文件夹
tag_path="s3://mob-emr-test/dataplatform/DataWareHouse/offline/kehan/path_monitor/science_path_tag"
hadoop fs -rmr $tag_path
hadoop fs -mkdir $tag_path

# 并发执行脚本获取路径信息
for i in `seq 0 $num`
do
sh get_path_info.sh  $cal_path$i
done

# 等待脚本全部执行结束
for i in `seq 0 $num`
do
check_await "${tag_path}/re_${cal_path}${i}_SUCCESS"
done

# 整合结果信息到一个文件
for i in `seq 0 $num`
do
cat re_$cal_path$i |while read line
do
echo $line >> ${out}
done
done

hadoop fs -rm s3://mob-emr-test/dataplatform/DataWareHouse/offline/kehan/path_monitor/${out}
hadoop fs -put ${out} s3://mob-emr-test/dataplatform/DataWareHouse/offline/kehan/path_monitor

# 数据入mysql并生成报表
java -jar science_monitor.jar
echo "end!"