#!/usr/bin/env bash

in=$1
format=format_$1
out=re_$1

tag_path="s3://mob-emr-test/dataplatform/DataWareHouse/offline/kehan/path_monitor/science_path_tag"

# 这里的-f参数判断结果文件是否存在 
rm ${out}
rm ${format}

sed 's#s3://mob-emr-test/dataplatform#dataplatform#' ${in} > ${format}

i=1
str="0"
# 循环读写
for line in `cat ${format}`
do
if [[ i -eq 1 ]]; then
    str=${line}
    i=2
else
    str="${str},${line}"
fi
done


S3Size -bucket mob-emr-test -dirs ${str} | awk -F ',' '{print "s3://mob-emr-test/"$1,$3,$4,$2}' | awk '{print $1,$2,$4,$6}'  > ${out}


hadoop fs -touchz ${tag_path}/${out}_SUCCESS
