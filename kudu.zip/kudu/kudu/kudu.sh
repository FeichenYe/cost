#!/bin/bash
source ../env.sh

# ===================================================================================

#hadoop fs -rmr "s3://mob-emr-test/jiangnan/temp/kudutest/2019060115"

dateTime="2019092601"

spark-submit --class com.mobvista.train_data_flow.task.kudu.KuduApplication \
	--conf spark.sql.shuffle.partitions=500 \
	--conf spark.default.parallelism=500 \
	--conf spark.yarn.executor.memoryOverhead=128 \
	--name "kudu_application" \
	--files ${HIVE_SITE_PATH} \
	--master yarn \
	--deploy-mode cluster \
	--executor-memory 1G \
	--driver-memory 1G \
	--executor-cores 1 \
	--num-executors 1 \
	--jars dataflow-sdk-1.0.jar,s3://mob-emr-test/dataplatform/DataWareHouse/offline/myjar/kudu-client-1.10.0.jar,s3://mob-emr-test/dataplatform/DataWareHouse/offline/myjar/kudu-spark2_2.11-1.10.0.jar \
	${JAR} ${dateTime}


