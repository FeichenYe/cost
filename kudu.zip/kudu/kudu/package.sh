#!/usr/bin/env bash

cd ././../../../dataflow-job/
mvn clean package || exit 1
mkdir target/kudu
cp azkaban-offline/env.sh target/kudu
cp -r azkaban-offline/kudu target/kudu
cp target/dataflow-job-1.0.jar target/kudu/kudu/train_data_flow.jar
