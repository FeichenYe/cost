#!/usr/bin/env bash

JAR=./train_data_flow.jar
HIVE_SITE_PATH="${SPARK_HOME}/conf/hive-site.xml"
#export HIVE_CONF_DIR=/data/azkaban-hadoop/command-home/hive-offline/conf

# 如果是线上azkaban访问线下hive表，需要声明此环境变量。反之，如果在线下azkaban，则不能声明这个变量。
#export HIVE_CONF_DIR=/data/azkaban-hadoop/command-home/hive-2.3.3-offline/conf

EXTRA_JARS="
../lib/dataflow-sdk-1.0.jar,\
oss://mob-emr-test/jiangnan/jars/spark-cassandra-connector_2.11-2.4.0.jar,\
oss://mob-emr-test/jiangnan/jars/groovy-all-2.4.9.jar,\
oss://mob-emr-test/jiangnan/jars/HdrHistogram-2.1.11.jar,\
oss://mob-emr-test/jiangnan/jars/kudu-client-1.10.0.jar,\
oss://mob-emr-test/jiangnan/jars/kudu-spark2_2.11-1.10.0.jar,\
oss://mob-emr-test/jiangnan/jars/fastjson-1.2.44.jar,\
oss://mob-emr-test/jiangnan/jars/snakeyaml-1.17.jar,\
oss://mob-emr-test/jiangnan/jars/config-1.2.1.jar,\
oss://mob-emr-test/xujian/jars/3S-Serde-1.1-SNAPSHOT.jar,\
oss://mob-emr-test/xujian/jars/Common-SerDe-1.0-SNAPSHOT.jar,\
oss://mob-emr-test/xujian/jars/EmrHadoopGoodies-1.4.0.jar,\
oss://mob-emr-test/xujian/jars/EmrHiveGoodies-1.4.0.jar,\
oss://mob-emr-test/xujian/jars/M-Serde-1.0-SNAPSHOT.jar,\
oss://mob-emr-test/xujian/jars/TestUDF-0.0.1-SNAPSHOT.jar,\
oss://mob-emr-test/xujian/jars/emr-ddb-hive-2.1.0.jar,\
oss://mob-emr-test/xujian/jars/emr-kinesis-hive-2.3.0.jar,\
oss://mob-emr-test/xujian/jars/json-serde-1.3.7-jar-with-dependencies.jar,\
oss://mob-emr-test/xujian/jars/m_serde.jar,\
oss://mob-emr-test/xujian/jars/opencsv-2.3.jar,\
oss://mob-emr-test/xujian/jars/rcfile-Serde-1.0-SNAPSHOT.jar"

RED_SHIFT_JARS="s3://mob-emr-test/liduo/jars/redshift-jdbc42-1.2.1.1001.jar"
PACKAGES="com.databricks:spark-redshift_2.11:3.0.0-preview1"

check_sucessfile() {
    local wait_time=1
    local wait_time_per=1
    local wait_total_time=1000
    local sucessfile_path=${1}
	while [ ${wait_time} -le ${wait_total_time} ];do
        hadoop dfs -test -e ${sucessfile_path}
		if [ $? -eq 0 ];then
		    echo "check ${sucessfile_path} is ok !!!!  "
			return 0
			break
		else
		    echo "${sucessfile_path} is not fond!!!  "
			sleep 5m
			wait_time=$[${wait_time}+${wait_time_per}]
		fi
	done
}


check_sucessfile_send_mail() {
    local wait_time=0
    local wait_time_per=5
    local wait_total_time=10000
    local sucessfile_path=${1}
    local send_mail_wait_time=${2}
    local send_mail_to_owner=${3}

	while [ ${wait_time} -le ${wait_total_time} ];do
        hadoop dfs -test -e ${sucessfile_path}
		if [ $? -eq 0 ];then
		    echo "check ${sucessfile_path} is ok !!!!  "
			return 0
			break
		else
		    if [ ${wait_time} -eq ${send_mail_wait_time} ];then
			    send_mail "monitor.dataPlatform@mobvista.com" "$send_mail_to_owner" "[报警]上游依赖延迟" "长时间未产出 $sucessfile_path </p><p>请check该数据，避免影响下游任务，谢谢</p>"
			fi
			sleep 5m
			wait_time=$[${wait_time}+${wait_time_per}]
			echo "${sucessfile_path} is not fond!!!  "
		fi
	done
}

del_s3_path() {
    local base_path=$1
    local rm_date=$2
    if [ ${#base_path} -eq 0 ];then
        echo "FATAL:del_s3_path failed, base_path string is empty!"
        return 1
    fi

    if [ ${#rm_date} -eq 0 ];then
        echo "FATAL:del_s3_path failed, data date string is empty!"
        return 1
    fi
    hadoop dfs -rmr $base_path/$rm_date
}

del_s3_file() {
    local base_path=$1
    if [ ${#base_path} -eq 0 ];then
        echo "FATAL:del_s3_path failed, base_path string is empty!"
        return 1
    fi
    hadoop dfs -rmr $base_path
}


# 获取最近生成的SUCCESS目录的日期
get_lastest_date() {
    local path="$1"
    local datehour="$2"

    while [[ true ]];
    do
        local date=${datehour:0:8}
        local hour=${datehour:8:2}
        local check_path="$path/$date/${datehour}/_SUCCESS"
        if hadoop fs -ls $check_path > /dev/null 2>&1
        then
            echo $datehour
            break
        fi
            local datehour=$(date -d "$date $hour 1 hour ago" "+%Y%m%d%H")
    done
}

# $1 com.mobvista.valyria.sql
hive_cmd() {
    local HIVE_CMD="hive"
    if [ ! -f $HIVE_CMD ];then
      HIVE_CMD="hive"
    fi
    ${HIVE_CMD} -e "
    set hive.cli.print.header=false;
    set hive.optimize.index.filter=true;
    set mapreduce.task.io.sort.mb=512;
    set mapreduce.map.speculative=true;
    set mapreduce.reduce.speculative=true;
    $1;
    "
}

function check_hive_partition_ready(){
        local table=$1
        local sql=$2
        local info_tag="$3"
        #select_date=`/data/hadoop-alternative/hive-offline/bin/hive -e " set hive.fetch.task.conversion=more;select concat(year,month,day) from ${table} where concat(year,month,day)='$cur_date' limit 1"`
        select_date=`hive -e " set hive.fetch.task.conversion=more;$sql"`
        echo $select_date
        select_date=`echo "$select_date" | tail -1`
        echo $select_date
        if [ "$select_date" != "$cur_date" ]; then
                echo "$info_tag $table $cur_date is not ready"
                return 1
        fi
}

function check_hive_partition() {
##### check hive table #####
# $1 table_name -> "db_name.table_name"
# $2 partition -> "day=${DATE}/dayhour=${CUR_DATE}"
############################
    WAIT_TIME=1
    BANTCH=1
    WAIT_TOTAL_TIME=1000
	while [ ${WAIT_TIME} -le ${WAIT_TOTAL_TIME} ];do
        temp=`hive -e "show partitions $1"`
        echo $temp|grep -wq "$2"
        if [ $? -eq 0 ];then
            echo "***********************************************************************************"
            echo "success paritition ->  table:$1 partition:$2"
            echo "ok!!!"
            echo "***********************************************************************************"
            return 0
            break
        else
            echo "***********************************************************************************"
            echo "failue paritition ->   table:$1 partition:$2"
            echo "waite 5m ... "
            echo "***********************************************************************************"
            sleep 5m
			WAIT_TIME=$[${WAIT_TIME}+${BANTCH}]
        fi
    done
}

function check_hive_partition_isExist() {
##### check hive table #####
# $1 table_name -> "db_name.table_name"
# $2 partition -> "day=${DATE}/dayhour=${CUR_DATE}"
############################
    temp=`hive -e "show partitions $1"`
    echo $temp|grep -wq "$2"
    if [ $? -eq 0 ];then
        echo "1"
    else
        echo "0"
    fi
}


check_hive_sucess_partition() {
##### check hive table #####
# $1 hdfs_path
# $2 sucess_path
# $3 table_name -> "db_name.table_name"
# $4 partition -> "day=${DATE}/dayhour=${CUR_DATE}"
############################
    local hdfs_path=$1
    local sucess_path=$2
    local table_name=$3
    local partition=$4
    WAIT_TIME=1
    BANTCH=1
    WAIT_TOTAL_TIME=100
	while [ ${WAIT_TIME} -le ${WAIT_TOTAL_TIME} ];do
	    hadoop dfs -test -e $sucess_path
		if [ $? -eq 0 ];then
            mount_partition $table_name $partition $hdfs_path
            echo "$table_name $partition is ok !!!! "
			return 0
			break
		else
			sleep 5m
			WAIT_TIME=$[${WAIT_TIME}+${WAIT_TIME_PER}]
			echo "${sucess_path} is failed !!! "
		fi
    done
}

# 挂载hive分区
# $1 table name
# $2 partition
# $3 hdfs path
mount_partition() {
    local count=1
    local limit=3
    while [ $count -le $limit ];do
       hive_cmd "
        use dwh;
        ALTER TABLE $1 ADD IF NOT EXISTS PARTITION ($2)
            LOCATION '$3';
        "

        if [ $? -eq 0 ];then
          break
        else
          if [ $count -eq $limit ];then
            exit 255
          else
            count=$(( $count + 1 ))
          fi
        fi
    done
}

# $1 db name
# $2 table name
# $3 partition
# $4 hdfs path
unmount_partition() {
    local count=1
    local limit=3
    while [ $count -le $limit ];do
       hive_cmd "
        use $1;
        ALTER TABLE $2 DROP IF EXISTS PARTITION ($3);
        "

        if [ $? -eq 0 ];then
            hadoop fs -rm -r $4
            break
        else
          if [ $count -eq $limit ];then
            exit 255
          else
            count=$(( $count + 1 ))
          fi
        fi
    done
}


# 发送邮件
# $1 发件人
# $2 收件人，逗号间隔
# $3 标题
# $4 正文
send_mail(){
  # 初始化参数
  local MAIL_FROM=$1
  local MAIL_MEMBERS=$2
  local MAIL_TITLE=$3
  local MAIL_BODY=$4

  # 组装内容
  local MAIL_MSG="$(echo "
    From:${MAIL_FROM}
    To:${MAIL_MEMBERS}
    Subject:${MAIL_TITLE}
    Content-Type: text/html; charset=utf-8
    <!DOCTYPE html PUBLIC -//W3C//DTD HTML 4.01 Transitional//ENhttp://www.w3.org/TR/html4/loose.dtd>
    <html>
      <head><meta http-equiv=Content-Type content=text/html; charset=utf-8 pageEncoding=UTF-8></head>
      <body>${MAIL_BODY}</body>
    </html>
  " | head -n-1 | tail -n+2 | sed -r 's/^[\t ]+//g')"

  # 发送邮件
  /usr/sbin/sendmail -t <<< "${MAIL_MSG}"
}